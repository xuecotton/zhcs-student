<template>
  <div>
    <!-- 学生平台系统 -->
    <van-nav-bar title="学生平台系统" left-text="返回" left-arrow>
      <router-link to="/" slot="left">
        <van-icon name="arrow-left" size="18" />
      </router-link>
    </van-nav-bar>
  </div>
</template>

<style lang="stylus" scoped></style>
