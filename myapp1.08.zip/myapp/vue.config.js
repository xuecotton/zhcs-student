"use strict"

module.exports = {
    publicPath: './',
    outputDir: '../cordovaPro/www',
    productionSourceMap: false

}